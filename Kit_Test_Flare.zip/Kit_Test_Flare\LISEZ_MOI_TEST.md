# Recette Flare — AIT Cleanup et AIT Import Finalizer

Ce kit est un projet de test jetable. Il ne contient aucune condition Author-it.

## 1. Ouvrir le projet

Dans MadCap Flare, ouvrir :

`Projet_Test_ATLAS/Projet_Test_ATLAS.flprj`

Vérifier que le plug-in ATLAS chargé est bien la version Release à tester.

## 2. Tester AIT Cleanup en premier

Dans **AIT Cleanup** :

1. Choisir **Whole project / Projet complet**.
2. Sélectionner le dossier `Projet_Test_ATLAS`.
3. Cocher toutes les transformations :
   - Actions / résultats
   - Listes à tirets
   - Callouts
   - Figures
   - Nettoyage des styles
   - IHM
4. Pour le XML Author-it, sélectionner `AuthorIt_Test_IHM.xml` situé à la racine du kit.
5. Le template **Menu_STR — ID 18564 — 2 topics français** doit apparaître. Le cocher.
6. Lancer le Cleanup.

Résultat attendu au premier passage :

- 2 fichiers `.htm` scannés ;
- 1 liste Action/Résultat ;
- 1 liste à tirets ;
- 1 callout Information ;
- 1 figure ;
- plusieurs styles simples nettoyés ;
- `Project/VariableSets/Menu_STR.flvar` généré avec 2 variables ;
- 2 références `Topic*.flsnp` remplacées par des variables MadCap ;
- aucune erreur ;
- une sauvegarde `AIT_Transformations.htm.before-ait-cleanup.bak` ;
- une sauvegarde horodatée de `IHM_References.htm` avant remplacement.

Relancer immédiatement le Cleanup une deuxième fois avec les mêmes choix. Les transformations de contenu et les remplacements IHM doivent être à zéro. La génération de `Menu_STR.flvar` peut néanmoins être de nouveau signalée.

> Important : effectuer ces deux passages avant le Finalizer. Après le Finalizer, les ressources ATLAS réelles sont installées dans `Content/Resources` et ne doivent pas servir de données d'entrée à cette recette Cleanup.

## 3. Tester AIT Import Finalizer

Dans **AIT Import Finalizer** :

1. Type de document : **Document technique**.
2. TOC : `Projet_Test_ATLAS/Project/TOCs/Test_Finalizer.fltoc`.
3. Target PDF : `Projet_Test_ATLAS/Project/Targets/Test_Finalizer_PDF.fltar`.
4. Renseigner :
   - Titre : `Guide de validation ATLAS`
   - Dispositif : `STA TEST`
   - Référence document : `DOC-TEST-001`
   - Indice : `B`
   - Langue : `FR`
   - Référence MREF : `MREF-TEST-001`
5. Cocher les quatre actions : ressources, TOC, variables, target.
6. Lancer le Finalizer.

Résultat attendu :

- les 4 entrées parasites de la TOC sont supprimées, mais `Chapitre utile` reste présent ;
- les ressources ATLAS sont copiées ;
- les anciens `Styles.css` et `General.flvar` possèdent une sauvegarde `.before-ait-finalizer.bak` ;
- `General.flvar` contient les valeurs saisies et possède aussi une sauvegarde `.bak` avant mise à jour ;
- la target pointe vers `Test_Finalizer.fltoc`, `Styles.css` et `Tech.flpgl` ;
- la target possède une sauvegarde `.bak` ;
- aucune erreur n'est affichée.

Relancer le Finalizer une deuxième fois. Il doit réussir sans créer une nouvelle sauvegarde initiale. Les ressources doivent être indiquées comme inchangées et `General.flvar` comme préservé.

## 4. Contrôle automatique après les deux tests

Depuis PowerShell, dans le dossier du kit :

```powershell
powershell -ExecutionPolicy Bypass -File .\VERIFIER_APRES_TEST.ps1
```

Le résultat attendu est : `VALIDATION COMPLETE : OK`.

Pour recommencer de zéro, supprimer le dossier extrait et extraire de nouveau `Kit_Test_Flare.zip`.
