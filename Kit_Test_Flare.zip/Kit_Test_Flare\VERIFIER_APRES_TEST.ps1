﻿$ErrorActionPreference = "Stop"
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
$kitRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Join-Path $kitRoot "Projet_Test_ATLAS"
$failures = New-Object System.Collections.Generic.List[string]

function Test-Rule {
    param(
        [string]$Label,
        [bool]$Condition
    )

    if ($Condition) {
        Write-Host "[OK]    $Label" -ForegroundColor Green
    }
    else {
        Write-Host "[ECHEC] $Label" -ForegroundColor Red
        $failures.Add($Label)
    }
}

function Get-LocalElements {
    param(
        [xml]$Document,
        [string]$LocalName
    )

    return @($Document.SelectNodes("//*[local-name()='$LocalName']"))
}

Write-Host "`n--- AIT Cleanup ---" -ForegroundColor Cyan

$cleanupTopicPath = Join-Path $projectRoot "Content\Tests\AIT_Transformations.htm"
$ihmTopicPath = Join-Path $projectRoot "Content\Tests\IHM_References.htm"
$menuVariablesPath = Join-Path $projectRoot "Project\VariableSets\Menu_STR.flvar"

[xml]$cleanupTopic = [System.IO.File]::ReadAllText($cleanupTopicPath, $utf8)
[xml]$ihmTopic = [System.IO.File]::ReadAllText($ihmTopicPath, $utf8)

Test-Rule "Sauvegarde initiale du topic Cleanup" (Test-Path -LiteralPath ($cleanupTopicPath + ".before-ait-cleanup.bak"))
Test-Rule "Liste Action_num créée" (@(Get-LocalElements $cleanupTopic "ol" | Where-Object { $_.class -eq "Action_num" }).Count -eq 1)
Test-Rule "Liste à puces créée" (@(Get-LocalElements $cleanupTopic "ul").Count -ge 1)
Test-Rule "Callout Information créé" (@(Get-LocalElements $cleanupTopic "div" | Where-Object { $_.class -eq "a_Information" }).Count -eq 1)
Test-Rule "Bloc figure créé" (@(Get-LocalElements $cleanupTopic "div" | Where-Object { $_.class -eq "a_figure" }).Count -eq 1)
$stylesPathForDisplay = Join-Path $projectRoot "Content\Resources\Stylesheets\Styles.css"
$informationIconPath = Join-Path $projectRoot "Content\Resources\Images\Picto_doc\MULTI_pic_PAT_Information2020.png"
$figurePngPath = Join-Path $projectRoot "Content\Resources\Images\Logos\MonLogo.png"
$stylesTextForDisplay = [System.IO.File]::ReadAllText($stylesPathForDisplay, $utf8)
Test-Rule "CSS du pictogramme Information installé" ($stylesTextForDisplay -match "div\.a_Information" -and $stylesTextForDisplay -match "MULTI_pic_PAT_Information2020\.png")
Test-Rule "PNG du pictogramme Information installé" (Test-Path -LiteralPath $informationIconPath)
Test-Rule "PNG de la figure installé" (Test-Path -LiteralPath $figurePngPath)
Test-Rule "Indice transformé en sub" (@(Get-LocalElements $cleanupTopic "sub").Count -eq 1)
Test-Rule "Exposant transformé en sup" (@(Get-LocalElements $cleanupTopic "sup").Count -eq 1)
Test-Rule "Paragraphe centré normalisé" (@(Get-LocalElements $cleanupTopic "p" | Where-Object { $_.class -eq "a_centre" }).Count -ge 1)
Test-Rule "Fichier Menu_STR.flvar généré" (Test-Path -LiteralPath $menuVariablesPath)

if (Test-Path -LiteralPath $menuVariablesPath) {
    [xml]$menuVariables = [System.IO.File]::ReadAllText($menuVariablesPath, $utf8)
    $menuVariableNames = @(Get-LocalElements $menuVariables "Variable" | ForEach-Object { $_.GetAttribute("Name") })
    Test-Rule "Deux variables Menu_STR générées" ($menuVariableNames.Count -eq 2)
    Test-Rule "Variable Abréviation présente" ($menuVariableNames -contains "Abréviation")
    Test-Rule "Variable Confirmer présente" ($menuVariableNames -contains "Confirmer")
}

$ihmVariableNames = @(Get-LocalElements $ihmTopic "variable" | ForEach-Object { $_.name })
Test-Rule "Référence IHM Abréviation remplacée" ($ihmVariableNames -contains "Menu_STR.Abréviation")
Test-Rule "Référence IHM Confirmer remplacée" ($ihmVariableNames -contains "Menu_STR.Confirmer")
Test-Rule "Sauvegarde du topic IHM créée" (@(Get-ChildItem -LiteralPath (Split-Path $ihmTopicPath) -Filter "IHM_References.htm.before-ihm-variables.*.bak").Count -eq 1)

Write-Host "`n--- AIT Import Finalizer ---" -ForegroundColor Cyan

$tocPath = Join-Path $projectRoot "Project\TOCs\Test_Finalizer.fltoc"
$targetPath = Join-Path $projectRoot "Project\Targets\Test_Finalizer_PDF.fltar"
$generalPath = Join-Path $projectRoot "Project\VariableSets\General.flvar"
$stylesPath = Join-Path $projectRoot "Content\Resources\Stylesheets\Styles.css"
$layoutPath = Join-Path $projectRoot "Content\Resources\PageLayouts\Tech.flpgl"

[xml]$toc = [System.IO.File]::ReadAllText($tocPath, $utf8)
[xml]$target = [System.IO.File]::ReadAllText($targetPath, $utf8)
[xml]$general = [System.IO.File]::ReadAllText($generalPath, $utf8)

$tocTitles = @(Get-LocalElements $toc "TocEntry" | ForEach-Object { $_.Title })
Test-Rule "Entrées parasites supprimées de la TOC" (!(($tocTitles -contains "A_HEADER") -or ($tocTitles -contains "A_FOOTER") -or ($tocTitles -contains "Table des matières") -or ($tocTitles -contains "Cover")))
Test-Rule "Chapitre utile conservé dans la TOC" ($tocTitles -contains "Chapitre utile")
Test-Rule "Sauvegarde initiale de la TOC" (Test-Path -LiteralPath ($tocPath + ".bak"))
Test-Rule "Styles.css installé" (Test-Path -LiteralPath $stylesPath)
Test-Rule "Tech.flpgl installé" (Test-Path -LiteralPath $layoutPath)
Test-Rule "Ancien Styles.css sauvegardé" (Test-Path -LiteralPath ($stylesPath + ".before-ait-finalizer.bak"))
Test-Rule "Ancien General.flvar sauvegardé" (Test-Path -LiteralPath ($generalPath + ".before-ait-finalizer.bak"))
Test-Rule "General.flvar sauvegardé avant mise à jour" (Test-Path -LiteralPath ($generalPath + ".bak"))
Test-Rule "Target sauvegardée" (Test-Path -LiteralPath ($targetPath + ".bak"))

$targetRoot = $target.DocumentElement
Test-Rule "Target reliée à la bonne TOC" ($targetRoot.MasterToc -match "Test_Finalizer\.fltoc$")
Test-Rule "Target reliée à Styles.css" ($targetRoot.MasterStylesheet -match "Resources[/\\]Stylesheets[/\\]Styles\.css$")
Test-Rule "Target reliée à Tech.flpgl" ($targetRoot.MasterPageLayout -match "Resources[/\\]PageLayouts[/\\]Tech\.flpgl$")

if (!(Test-Path -LiteralPath ($targetPath + ".bak"))) {
    Write-Host "[INFO]  La target est intacte : relancer uniquement l'action 'Configurer la TOC, le style et le layout de la target'." -ForegroundColor Yellow
}

$generalVariables = @(Get-LocalElements $general "Variable")
function Has-GeneralValue {
    param([string]$Name, [string]$Value)
    return @($generalVariables | Where-Object { $_.GetAttribute("Name") -ieq $Name -and $_.InnerText.Trim() -eq $Value }).Count -ge 1
}

Test-Rule "DocumentTitle mis à jour" (Has-GeneralValue "DocumentTitle" "Guide de validation ATLAS")
Test-Rule "Dispositif mis à jour" (Has-GeneralValue "dispositif" "STA TEST")
Test-Rule "Référence document mise à jour" (Has-GeneralValue "DocumentReference" "DOC-TEST-001")
Test-Rule "Indice mis à jour" (Has-GeneralValue "Indice" "B")
Test-Rule "Langue mise à jour" (Has-GeneralValue "DocumentLanguage" "FR")
Test-Rule "MREF mise à jour" (Has-GeneralValue "Mref" "MREF-TEST-001")

if ($failures.Count -eq 0) {
    Write-Host "`nVALIDATION COMPLETE : OK" -ForegroundColor Green
    exit 0
}

Write-Host "`nVALIDATION INCOMPLETE : $($failures.Count) ECHEC(S)" -ForegroundColor Red
exit 1
